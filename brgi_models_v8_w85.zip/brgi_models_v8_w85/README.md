# BRGI Datathon 2026 — trained models for solution_v8_w85.csv (Team VAWAR)

This folder holds 60 LightGBM quantile boosters (`boosters/*.txt`, LightGBM native text format):
- 2 blend members: **direct**, and **anchored** (a residual over the last BRGI)
- × 2 district types: **seen** (full features), and **unseen** (no-bank features)
- × 3 quantiles (0.1, 0.5, 0.9)
- × 5 seeds (42, 7, 2026, 11, 99)

`model_config.json` lists every booster file with its member, district type, quantile, seed, number of rounds and anchor.
It also lists the exact feature lists and the blending rule: average the members, scale p10/p90 around p50 by ×0.85, sort, and clip to [0, 100].

## Reproduce the submission without training
```bash
pip install lightgbm pandas numpy pyarrow
export BRGI_DATA=/path/to/competition/csvs/
python predict_from_models.py      # writes solution.csv
```
`solution_from_saved_models.csv` was produced from these saved files and matches the submitted
`solution_v8_w85.csv` exactly: the maximum absolute difference is 0.0 across all 2,472 rows.
