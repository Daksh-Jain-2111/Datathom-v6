"""Rebuild solution.csv from the saved LightGBM boosters (no training).
Usage:  BRGI_DATA=/path/to/competition/csvs/  python predict_from_models.py
Needs the src/ files (common, features, augment, model) next to this script."""
import json, numpy as np, pandas as pd, lightgbm as lgb
from common import load, DATA
from features import build
from augment import build_rows, ENV
from model import anchor_values, finalize

cfg = json.load(open('model_config.json'))
tr, te = load()
if cfg['version'] == 'v2':
    df = build(tr, te)
else:
    aug = build_rows(['2024Q1', '2024Q2', '2024Q3'], tr, te)
    if cfg['version'] == 'v6':
        for c in ('ntl_yoy_l1', 'ntl_qoq_l1', 'nbr_mean_ntl_yoy_l1'):
            aug[c] = aug[c] - np.log(3)
    trm = pd.concat([tr, aug], ignore_index=True); trm[ENV] = np.nan
    te = te.copy(); te[ENV] = np.nan
    df = build(trm, te)
lab = df[df._is_test == 0]; tst = df[df._is_test == 1]
seen = tst.district_id.isin(set(lab.district_id)).values
feats = {'seen': cfg['features_full'], 'unseen': cfg['features_nobank']}
QS = [0.1, 0.5, 0.9]; members = sorted({b['member'] for b in cfg['boosters']})
acc = np.zeros((len(tst), 3))
for b in cfg['boosters']:
    mask = seen if b['district_type'] == 'seen' else ~seen
    pred = lgb.Booster(model_file='boosters/' + b['file']).predict(tst[mask][feats[b['district_type']]])
    pred = pred + anchor_values(tst[mask], b['anchor'])
    acc[mask, QS.index(b['quantile'])] += pred / len(cfg['seeds']) / len(members)
w = cfg['widen']
p10 = acc[:, 1] - w * (acc[:, 1] - acc[:, 0]); p90 = acc[:, 1] + w * (acc[:, 2] - acc[:, 1])
P = np.column_stack(finalize(p10, acc[:, 1], p90))
sub = pd.read_csv(DATA + 'sample_submission.csv')[['id']].merge(
    pd.DataFrame({'id': tst.id.values, 'p10': P[:, 0], 'p50': P[:, 1], 'p90': P[:, 2]}), on='id')
assert sub.notna().all().all() and (sub.p10 <= sub.p50).all() and (sub.p50 <= sub.p90).all()
sub.to_csv('solution.csv', index=False, float_format='%.4f'); print('solution.csv written', sub.shape)
