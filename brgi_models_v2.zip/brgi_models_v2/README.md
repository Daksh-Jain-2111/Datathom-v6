# BRGI Datathon 2026 — trained models for solution_v2.csv (Team VAWAR)

This folder holds 36 LightGBM quantile boosters (`boosters/*.txt`, LightGBM native text format):
- 2 blend members: **direct**, and **anchored** (a residual over the last BRGI)
- × 2 district types: **seen** (full features), and **unseen** (no-bank features)
- × 3 quantiles (0.1, 0.5, 0.9)
- × 3 seeds (42, 7, 2026)

v2 is trained on train.csv as provided, with the weather, fire and news features included. It has no resilience-proxy features and no rebuilt origins.
`model_config.json` lists every booster file with its settings, the exact feature lists and the blending rule:
average the members, sort, and clip to [0, 100], with no interval rescaling.

## Reproduce the submission without training
```bash
pip install lightgbm pandas numpy pyarrow
export BRGI_DATA=/path/to/competition/csvs/
python predict_from_models.py      # writes solution.csv
```
`solution_from_saved_models.csv` was produced from these saved files and matches `solution_v2.csv` exactly: the maximum absolute difference is 0.0.
